Still under progress 
based on Natural language processing i will share details once i complete it 

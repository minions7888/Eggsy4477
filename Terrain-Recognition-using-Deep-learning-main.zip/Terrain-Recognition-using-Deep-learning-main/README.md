# Terrain-Recognition-using-Deep-learning
This is Terrain recognition project which is based on satellite image 
dataset: Landsat 8 terrain screenshots within range 2 km to 50 km scale 
augumentation and preprocessing : images are rotated , flipped , sheared , etc ...
